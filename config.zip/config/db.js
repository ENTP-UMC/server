
export const dbconfig= {
   host     : 'localhost',
   user     : 'root',
   password : 'joon5849',
   database : 'umc'
};

